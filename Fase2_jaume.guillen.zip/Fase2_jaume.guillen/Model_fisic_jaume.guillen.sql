-- Database: postgres

-- DROP DATABASE postgres;

DROP TABLE IF EXISTS Apartment_imp CASCADE;
CREATE TABLE Apartment_imp(

	id INT,
	listing_url VARCHAR(255),
	name VARCHAR(255),
	description text,
	picture_url VARCHAR(255),
	street VARCHAR(255),
	neighbourhood_cleansed VARCHAR(255),
	city VARCHAR(255),
	state VARCHAR(255),
	zipcode VARCHAR(255),
	country_code VARCHAR(255),
	country VARCHAR(255),
	property_type VARCHAR(255),
	accomodates INT,
	bathrooms real,
	bedrooms INT,
	beds INT,
	amenities text,
	square_feet INT,
	price VARCHAR(255),
	weekly_price VARCHAR(255),
	monthly_price VARCHAR(255),
	security_deposit VARCHAR(255),
	cleaning_fee VARCHAR(255),
	minimum_nights INT,
	maximum_nights INT

);

DROP TABLE IF EXISTS Hosts_imp CASCADE;
CREATE TABLE Hosts_imp(
	
	listing_url VARCHAR(255),
	name VARCHAR(255),
	description text,
	picture_url VARCHAR(255),
	host_id INT,
	host_url VARCHAR(255),
	host_name VARCHAR(255),
	host_since DATE,
	host_about text,
	host_response_time VARCHAR(255),
	host_response_rate VARCHAR(255),
	host_is_superhost bool,
	host_picture_url VARCHAR(255),
	host_listings_count INT,
	host_verifications VARCHAR(255),
	host_identity_veryfied bool

);

DROP TABLE IF EXISTS Review_imp CASCADE;
CREATE TABLE Review_imp(

	id INT,
	listing_url VARCHAR(255),
	name VARCHAR(255),
	description text,
	picture_url VARCHAR(255),
	street VARCHAR(255),
	neighbourhood_cleansed VARCHAR(255),
	city VARCHAR(255),
	date_review DATE,
	reviewer_id INT,
	reviewer_name VARCHAR(255),
	comments text

);

COPY Apartment_imp FROM 'C:/Users/Public/Downloads/apartments.csv' DELIMITER ',' CSV HEADER;
COPY Hosts_imp FROM 'C:/Users/Public/Downloads/hosts.csv' DELIMITER ',' CSV HEADER;
COPY Review_imp FROM 'C:/Users/Public/Downloads/review.csv' DELIMITER ',' CSV HEADER;

DROP TABLE IF EXISTS Host CASCADE;
CREATE TABLE Host(

	host_id INT,
	host_url VARCHAR(255),
	host_name VARCHAR(255),
	host_since DATE,
	host_about text,
	host_response_time VARCHAR(255),
	host_response_rate VARCHAR(255),
	host_is_superhost bool,
	host_picture_url VARCHAR(255),
	host_listings_count INT,
	host_identity_veryfied bool,
	PRIMARY KEY(host_id)

);

DROP TABLE IF EXISTS Host_verification CASCADE;
CREATE TABLE Host_verification(

	name_host_verification VARCHAR(255),
	PRIMARY KEY(name_host_verification)

);

DROP TABLE IF EXISTS HostHost_verification CASCADE;
CREATE TABLE HostHost_verification(

	host_id INT,
	name_host_verification VARCHAR(255),
	PRIMARY KEY(host_id, name_host_verification),
	FOREIGN KEY(host_id) REFERENCES Host(host_id),
	FOREIGN KEY(name_host_verification) REFERENCES Host_verification(name_host_verification)

);

DROP TABLE IF EXISTS Country CASCADE;
CREATE TABLE Country(

	country_code VARCHAR(255),
	country_name VARCHAR(255),
	PRIMARY KEY(country_code)

);

DROP TABLE IF EXISTS State CASCADE;
CREATE TABLE State(

	id_state VARCHAR(255),
	name_state VARCHAR(255),
	country_code VARCHAR(255),
	PRIMARY KEY(id_state),
	FOREIGN KEY(country_code) REFERENCES Country(country_code)

);

DROP TABLE IF EXISTS City CASCADE;
CREATE TABLE City(

	id_city VARCHAR(255),
	name_city VARCHAR(255),
	id_state VARCHAR(255),
	PRIMARY KEY(id_city),
	FOREIGN KEY(id_state) REFERENCES State(id_state)

);

DROP TABLE IF EXISTS Neighbourhood CASCADE;
CREATE TABLE Neighbourhood(

	id_neighbourhood VARCHAR(255),
	name_neighbourhood VARCHAR(255),
	id_city VARCHAR(255),
	PRIMARY KEY(id_neighbourhood),
	FOREIGN KEY(id_city) REFERENCES City(id_city)

);

DROP TABLE IF EXISTS Street CASCADE;
CREATE TABLE Street(

	id_street VARCHAR(255),
	name_street VARCHAR(255),
	id_neighbourhood VARCHAR(255),
	PRIMARY KEY(id_street),
	FOREIGN KEY(id_neighbourhood) REFERENCES Neighbourhood(id_neighbourhood)

);

DROP TABLE IF EXISTS Apartment CASCADE;
CREATE TABLE Apartment(

	id_apartment INT,
	listing_url VARCHAR(255),
	name VARCHAR(255),
	description text,
	zipcode VARCHAR(255),
	property_type VARCHAR(255),
	accomodates INT,
	bathrooms real,
	bedrooms INT,
	beds INT,
	square_feet INT,
	price VARCHAR(255),
	weekly_price VARCHAR(255),
	monthly_price VARCHAR(255),
	security_deposit VARCHAR(255),
	cleaning_fee VARCHAR(255),
	minimum_nights INT,
	maximum_nights INT,
	host_id INT,
	id_street VARCHAR(255),
	PRIMARY KEY(id_apartment),
	FOREIGN KEY(id_street) REFERENCES Street(id_street),
	FOREIGN KEY(host_id) REFERENCES Host(host_id)

);

DROP TABLE IF EXISTS PictureUrl CASCADE;
CREATE TABLE PictureUrl(

	picture_url VARCHAR(255),
	PRIMARY KEY(picture_url)

);

DROP TABLE IF EXISTS ApartmentPictureUrl CASCADE;
CREATE TABLE ApartmentPictureUrl(

	id_apartment INT,
	picture_url VARCHAR(255),
	PRIMARY KEY(id_apartment, picture_url),
	FOREIGN KEY(id_apartment) REFERENCES Apartment(id_apartment),
	FOREIGN KEY(picture_url) REFERENCES PictureUrl(picture_url)

);

DROP TABLE IF EXISTS Amenity CASCADE;
CREATE TABLE Amenity(

	name_amenity VARCHAR(255),
	PRIMARY KEY(name_amenity)

);

DROP TABLE IF EXISTS ApartmentAmenity CASCADE;
CREATE TABLE ApartmentAmenity(

	id_apartment INT,
	name_amenity VARCHAR(255),
	PRIMARY KEY(id_apartment, name_amenity),
	FOREIGN KEY(id_apartment) REFERENCES Apartment(id_apartment),
	FOREIGN KEY(name_amenity) REFERENCES Amenity(name_amenity)

);

DROP TABLE IF EXISTS Reviewer CASCADE;
CREATE TABLE Reviewer(

	reviewer_id INT,
	reviewer_name VARCHAR(255),
	PRIMARY KEY(reviewer_id)

);

DROP TABLE IF EXISTS Review CASCADE;
CREATE TABLE Review(

	id_review serial,
	date_review DATE,
	comments text,
	id_reviewer INT,
	id_apartment INT,
	PRIMARY KEY(id_review),
	FOREIGN KEY(id_reviewer) REFERENCES Reviewer(reviewer_id),
	FOREIGN KEY(id_apartment) REFERENCES Apartment(id_apartment)

);
