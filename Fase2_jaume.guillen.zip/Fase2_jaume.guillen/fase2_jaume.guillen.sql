#&&
SELECT c.name_city AS name, (SUM(7*CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float) - COALESCE(CAST(REPLACE(REPLACE(a.weekly_price, '$', ''), ',', '') AS float), 7*CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)))/SUM(7*CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)))*100 AS savings_percentage
FROM City AS c, Neighbourhood AS n, Street AS s, Apartment AS a, Host AS h
WHERE a.id_street = s.id_street AND s.id_neighbourhood = n.id_neighbourhood AND n.id_city = c.id_city AND h.host_id = a.host_id AND h.host_identity_veryfied = TRUE
GROUP BY c.id_city
ORDER BY savings_percentage DESC;
#&&
SELECT a.name AS name, CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)/a.square_feet AS price_m2, COUNT(r.id_review) AS reviews
FROM Apartment AS a, Review AS r
WHERE r.id_apartment = a.id_apartment AND a.square_feet IS NOT NULL AND a.square_feet != 0 AND property_type LIKE '%Guesthouse%'
GROUP BY a.id_apartment
HAVING  COUNT(r.id_review) >= 200
ORDER BY price_m2 DESC
LIMIT 1;
#&&
SELECT a.name AS name, a.listing_url AS url, CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)*30 + CAST(REPLACE(REPLACE(a.cleaning_fee, '$', ''), ',', '') AS float) + CAST(REPLACE(REPLACE(a.security_deposit, '$', ''), ',', '') AS float) * 0.1 AS price
FROM Apartment AS a, Host AS h, ApartmentAmenity AS am, Street AS s, Neighbourhood AS n
WHERE a.host_id = h.host_id AND am.id_apartment = a.id_apartment AND am.name_amenity LIKE '%Balcony%' AND h.host_response_rate NOT LIKE '%N/A%' AND a.bathrooms > 1.5 AND CAST(REPLACE(REPLACE(h.host_response_rate, '%', ''), ',', '') AS float) > 0.9 AND a.accomodates = 6 AND a.property_type LIKE '%Apartment%' AND a.id_street = s.id_street AND s.id_neighbourhood = n.id_neighbourhood AND n.name_neighbourhood LIKE 'Port Phillip'
ORDER BY price;
#&&
UPDATE Host
SET host_is_superhost = true
WHERE EXTRACT(YEAR FROM host_since)<=2014;

UPDATE Host
SET host_is_superhost = false
WHERE EXTRACT(YEAR FROM host_since)>2014;

SELECT COUNT(h.host_id) AS superhosts
FROM Host AS h
WHERE h.host_is_superhost = true;

SELECT COUNT(h.host_id) AS normal_hosts
FROM Host AS h
WHERE h.host_is_superhost = false;
#&&
SELECT s.name_street AS street, COUNT(a.id_apartment) AS num, AVG(CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)) AS price
FROM Street AS s, Apartment AS a
WHERE s.id_street = a.id_street
GROUP BY s.id_street
HAVING AVG(CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)) < 100
ORDER BY COUNT(a.id_apartment) DESC
LIMIT 3;
#&&
SELECT r.reviewer_name, a.listing_url, COUNT(re.id_review) AS num_reviews
FROM Reviewer AS r, Review AS re, Apartment AS a
WHERE r.reviewer_id = re.id_reviewer AND a.id_apartment = re.id_apartment
GROUP BY a.id_apartment, r.reviewer_name
ORDER BY num_reviews DESC
LIMIT 3;
--Les reviews de Therese son falses ja que son frases d'una sola linia i es van repetint.
#&&
SELECT a.id_apartment, a.name, CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)*4 + CAST(REPLACE(REPLACE(a.cleaning_fee, '$', ''), ',', '') AS float) + CAST(REPLACE(REPLACE(a.security_deposit, '$', ''), ',', '') AS float) * 0.1 AS price
FROM Apartment AS a, Amenity AS am, ApartmentAmenity AS aam, Street AS s, Neighbourhood AS n, City AS c, Host AS h, Host_verification AS hv, HostHost_verification hhv
WHERE a.id_apartment = aam.id_apartment AND am.name_amenity = aam.name_amenity AND a.id_street = s.id_street AND s.id_neighbourhood = n.id_neighbourhood AND c.id_city = n.id_city AND a.host_id = h.host_id AND h.host_id = hhv.host_id AND hv.name_host_verification = hhv.name_host_verification AND c.name_city LIKE '%Saint Kilda%' AND am.name_amenity LIKE '%Kitchen%' AND hv.name_host_verification LIKE '%phone%' AND CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float)*4 + CAST(REPLACE(REPLACE(a.cleaning_fee, '$', ''), ',', '') AS float) + CAST(REPLACE(REPLACE(a.security_deposit, '$', ''), ',', '') AS float) * 0.1 <= 5000 AND a.accomodates >= 2 AND a.property_type LIKE '%Apartment%'
ORDER BY price DESC;
#&&
DROP TABLE IF EXISTS AuxTable CASCADE;
CREATE TABLE AuxTable(

	host_id INT,
	host_verificationCount INT,
	id_apartmentCount INT,
	PRIMARY KEY(host_id)

);
INSERT INTO AuxTable(host_id, host_verificationCount, id_apartmentCount)
SELECT DISTINCT h.host_id, COUNT(hv.name_host_verification), COUNT(a.id_apartment)
FROM Host AS h, Host_verification hv, HostHost_verification AS hhv, Apartment AS a
WHERE a.host_id = h.host_id AND h.host_id = hhv.host_id AND hhv.name_host_verification = hv.name_host_verification
GROUP BY h.host_id;

SELECT h.host_name, SUM((1/(CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float))))*(1 + CASE WHEN h.host_is_superhost THEN 1 ELSE 0 END)*aux.host_verificationCount*aux.id_apartmentCount AS score
FROM Host AS h, Apartment AS a, AuxTable AS Aux
WHERE a.host_id = h.host_id AND aux.host_id = h.host_id AND CAST(REPLACE(REPLACE(a.price, '$', ''), ',', '') AS float) != 0
GROUP BY h.host_name, aux.host_verificationCount, aux.id_apartmentCount, h.host_is_superhost
ORDER BY score DESC
LIMIT 3;
#&&
DROP TABLE IF EXISTS AuxTable1 CASCADE;
CREATE TABLE AuxTable1(

	points INT,
	reviewer_id INT

);
								 
INSERT INTO AuxTable1(points, reviewer_id)
SELECT COUNT(re.id_review)*10, r.reviewer_id
FROM Reviewer AS r, Review AS re
WHERE r.reviewer_id = re.id_reviewer AND LENGTH(re.comments) < 100
GROUP BY r.reviewer_id;
 
DROP TABLE IF EXISTS AuxTable2 CASCADE;
CREATE TABLE AuxTable2(

	points INT,
	reviewer_id INT

);
								 
INSERT INTO AuxTable2(points, reviewer_id)
SELECT COUNT(re.id_review)*15, r.reviewer_id
FROM Reviewer AS r, Review AS re
WHERE r.reviewer_id = re.id_reviewer AND LENGTH(re.comments) >= 100
GROUP BY r.reviewer_id;
								 
SELECT r.reviewer_name, aux1.points + aux2.points AS points
FROM Reviewer AS r, AuxTable1 AS aux1, AuxTable2 AS aux2
WHERE aux1.reviewer_id = r.reviewer_id AND aux2.reviewer_id = r.reviewer_id
ORDER BY points DESC
LIMIT 10;
#&&
--Show the 3 most used property types and the number of veryfied hosts they have
SELECT a.property_type, COUNT(a.id_apartment) AS number_of_apartments, SUM(CASE WHEN h.host_identity_veryfied THEN 1 ELSE 0 END) AS number_of_veryfied_hosts
FROM Apartment AS a, Host AS h
WHERE h.host_id = a.host_id
GROUP BY a.property_type
ORDER BY number_of_apartments DESC
LIMIT 3;