-- Database: postgres

-- DROP DATABASE postgres;

INSERT INTO Host(host_id, host_url, host_name, host_since, host_about, host_response_time, host_response_rate, host_is_superhost, host_picture_url, host_listings_count, host_identity_veryfied)
SELECT DISTINCT host_id, host_url, host_name, host_since, host_about, host_response_time, host_response_rate, host_is_superhost, host_picture_url, host_listings_count, host_identity_veryfied
FROM Hosts_imp;

INSERT INTO Host_verification(name_host_verification)
SELECT DISTINCT regexp_split_to_table(h.host_verifications, E',')
FROM Hosts_imp AS h;

INSERT INTO HostHost_verification(host_id, name_host_verification)
SELECT DISTINCT h.host_id, regexp_split_to_table(h.host_verifications, E',')
FROM Hosts_imp AS h;

INSERT INTO Country(country_code, country_name)
SELECT DISTINCT country_code, country
FROM Apartment_imp;

UPDATE Apartment_imp
SET state = 'Null'
WHERE state IS NULL;

INSERT INTO State(name_state, country_code, id_state)
SELECT DISTINCT state, country_code, CONCAT(country, ',', state)
FROM Apartment_imp;

INSERT INTO City(name_city, id_state, id_city)
SELECT DISTINCT a.city, s.id_state, CONCAT(s.id_state, ',', a.city)
FROM Apartment_imp AS a, State AS s
WHERE a.state = s.name_state;

INSERT INTO Neighbourhood(name_neighbourhood, id_city, id_neighbourhood)
SELECT DISTINCT a.neighbourhood_cleansed, c.id_city, CONCAT(c.id_city, ',', a.neighbourhood_cleansed)
FROM Apartment_imp AS a, City AS c
WHERE a.city = c.name_city;

INSERT INTO Street(name_street, id_neighbourhood, id_street)
SELECT DISTINCT a.street, n.id_neighbourhood, CONCAT(n.id_neighbourhood, ',', a.street)
FROM Apartment_imp AS a, Neighbourhood AS n
WHERE a.neighbourhood_cleansed = n.name_neighbourhood;

INSERT INTO Apartment(id_apartment, listing_url, name, description, zipcode, property_type, accomodates, bathrooms, bedrooms, beds, square_feet, price, weekly_price, monthly_price, security_deposit, cleaning_fee, minimum_nights, maximum_nights, host_id, id_street)
SELECT DISTINCT a.id, a.listing_url, a.name, a.description, a.zipcode, a.property_type, a.accomodates, a.bathrooms, a.bedrooms, a.beds, a.square_feet, a.price, a.weekly_price, a.monthly_price, a.security_deposit, a.cleaning_fee, a.minimum_nights, a.maximum_nights, h.host_id, s.id_street
FROM Street AS s, Apartment_imp AS a, Hosts_imp AS h
WHERE s.id_street = CONCAT(a.country, ',', a.state, ',', a.city, ',', a.neighbourhood_cleansed, ',', a.street) AND h.listing_url = a.listing_url;

INSERT INTO Amenity(name_amenity)
SELECT DISTINCT regexp_split_to_table(a.amenities, E',')
FROM Apartment_imp AS a;

INSERT INTO ApartmentAmenity(id_apartment, name_amenity)
SELECT DISTINCT a.id, regexp_split_to_table(a.amenities, E',')
FROM Apartment_imp AS a;

INSERT INTO PictureUrl(picture_url)
SELECT DISTINCT a.picture_url
FROM Apartment_imp AS a;

INSERT INTO ApartmentPictureUrl(id_apartment, picture_url)
SELECT DISTINCT a.id, a.picture_url
FROM Apartment_imp AS a;

INSERT INTO Reviewer(reviewer_id, reviewer_name)
SELECT DISTINCT reviewer_id, reviewer_name
FROM Review_imp;

INSERT INTO Review(date_review, comments, id_reviewer, id_apartment)
SELECT date_review, comments, reviewer_id, id
FROM Review_imp;